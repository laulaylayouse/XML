package com.example.xml_format_laila

data class Students(val id: Int, val name: String , val marks: Float)
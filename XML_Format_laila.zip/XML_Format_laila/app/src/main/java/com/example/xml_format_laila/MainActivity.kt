package com.example.xml_format_laila

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var Recycler_View: RecyclerView
    private  var Students_List = arrayListOf<Students>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Recycler_View = findViewById(R.id.Recycler_View)

        try {
            val parser = XmlPullParserHandler()
            val assets = applicationContext!!.assets.open("students.xml")
            val parsedAssets = parser.parse(assets)
            Students_List.addAll(parsedAssets)
            Recycler_View.adapter?.notifyDataSetChanged()
        } catch (io: IOException){
            io.printStackTrace()
        }

        Recycler_View.adapter = Adapter(Students_List)
        Recycler_View.layoutManager = LinearLayoutManager(this)
    }
}
package com.example.xml_format_laila

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.InputStream

class XmlPullParserHandler {
    private val student_list = ArrayList<Students>()
    private var student: Students? = null
    private var text: String? = null

    private var student_name = ""
    private var student_marks = 0f
    private var student_id = 0

    fun parse(inputStream: InputStream): List<Students> {
        try {

            var pull_Parser_Factory = XmlPullParserFactory.newInstance()
            var pull_Parser = pull_Parser_Factory.newPullParser()
            pull_Parser.setInput(inputStream, null)

            var event_Type = pull_Parser.eventType

            while (event_Type != XmlPullParser.END_DOCUMENT) {

                val name = pull_Parser.name

                when (event_Type) {
                    XmlPullParser.TEXT -> text = pull_Parser.text
                    XmlPullParser.END_TAG -> when {
                        name.equals("name", ignoreCase = true) -> {
                            student_name = text.toString()
                        }
                        name.equals("id", ignoreCase = true) -> {
                            student_id = text!!.toInt()
                        }
                        name.equals("marks", ignoreCase = true) -> {
                            student_marks = text!!.toFloat()
                            student_list.add(Students(student_id, student_name, student_marks))
                        }
                    }
                }

                event_Type = pull_Parser.next()

            }


        }
        catch (e: XmlPullParserException) {
            e.printStackTrace()
        }
        catch (e: IOException) {
            e.printStackTrace()
        }
        return student_list
    }
}  

package com.example.rssfeed_practice

import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var Recycler_View: RecyclerView
    var Questions_List = arrayListOf<Questions>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Recycler_View = findViewById(R.id.Recycler_View_main)
        FetchTopQuestions().execute()

    }

    private inner class FetchTopQuestions : AsyncTask<Void, Void, MutableList<Questions>>() {
        val parser = XMLParser()
        override fun doInBackground(vararg params: Void?): MutableList<Questions> {
            val url = URL("https://stackoverflow.com/feeds")
            val urlConnection = url.openConnection() as HttpURLConnection
            Questions_List = urlConnection.inputStream?.let { parser.parse(it) } as ArrayList<Questions>
            return Questions_List
        }

        override fun onPostExecute(result: MutableList<Questions>?) {
            super.onPostExecute(result)

            Recycler_View.adapter = Adapter(Questions_List)
            Recycler_View.layoutManager = LinearLayoutManager(this@MainActivity)
            Recycler_View.adapter?.notifyDataSetChanged()
        }

    }
}
package com.example.rssfeed_practice

data class Questions(val title: String?) {
    override fun toString(): String = title!!
}